package com.secureLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecureLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecureLoginApplication.class, args);
	}

}
