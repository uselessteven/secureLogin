package com.secureLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
